// ===============================
// SHOW / HIDE PASSWORD
// ===============================

function togglePassword(inputId, eyeId) {

    const input = document.getElementById(inputId);
    const eye = document.getElementById(eyeId);

    if (input.type === "password") {

        input.type = "text";

        eye.classList.remove("bi-eye");
        eye.classList.add("bi-eye-slash");

    } else {

        input.type = "password";

        eye.classList.remove("bi-eye-slash");
        eye.classList.add("bi-eye");

    }

}

// ===============================
// PASSWORD STRENGTH
// ===============================

const passwordInput = document.getElementById("password");
const strengthBar = document.getElementById("strengthBar");
const strengthText = document.getElementById("strengthText");

passwordInput.addEventListener("keyup", function () {

    const password = passwordInput.value;

    let strength = 0;

    if (password.length >= 8) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;

    switch (strength) {

        case 0:
        case 1:
            strengthBar.style.width = "20%";
            strengthBar.className = "progress-bar bg-danger";
            strengthText.innerHTML = "Weak Password";
            break;

        case 2:
            strengthBar.style.width = "40%";
            strengthBar.className = "progress-bar bg-warning";
            strengthText.innerHTML = "Fair Password";
            break;

        case 3:
            strengthBar.style.width = "60%";
            strengthBar.className = "progress-bar bg-info";
            strengthText.innerHTML = "Good Password";
            break;

        case 4:
            strengthBar.style.width = "80%";
            strengthBar.className = "progress-bar bg-primary";
            strengthText.innerHTML = "Strong Password";
            break;

        case 5:
            strengthBar.style.width = "100%";
            strengthBar.className = "progress-bar bg-success";
            strengthText.innerHTML = "Very Strong Password";
            break;

    }

});

// ===============================
// SIGNUP FORM
// ===============================

document.getElementById("signupForm").addEventListener("submit", function (e) {

    e.preventDefault();

    const fullname = document.getElementById("fullname").value.trim();
    const email = document.getElementById("email").value.trim();
    const mobile = document.getElementById("mobile").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const terms = document.getElementById("terms").checked;

    // Full Name
    if (fullname.length < 3) {

        alert("Please enter a valid full name.");

        return;

    }

    // Email Validation
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,}$/;

    if (!email.match(emailPattern)) {

        alert("Please enter a valid email address.");

        return;

    }

    // Mobile Validation
    const mobilePattern = /^[6-9]\d{9}$/;

    if (!mobile.match(mobilePattern)) {

        alert("Please enter a valid 10-digit mobile number.");

        return;

    }

    // Password Length
    if (password.length < 8) {

        alert("Password must be at least 8 characters.");

        return;

    }

    // Password Match
    if (password !== confirmPassword) {

        alert("Passwords do not match.");

        return;

    }

    // Terms
    if (!terms) {

        alert("Please accept the Terms & Conditions.");

        return;

    }

    // User Object
    const user = {

        fullname: fullname,
        email: email,
        mobile: mobile,
        password: password

    };

    // Save to Local Storage
    localStorage.setItem("localmartUser", JSON.stringify(user));

    alert("🎉 Account Created Successfully!");

    // Redirect
    window.location.href = "login.html";

});