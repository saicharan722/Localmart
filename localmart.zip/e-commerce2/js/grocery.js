
const products = [

{
id:1,
name:"Amul Taaza Milk",
category:"Dairy",
brand:"Amul",
weight:"500 ml",
price:32,
oldPrice:36,
rating:4.8,
offer:"10% OFF",
image:"https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=800&q=80"
},

{
id:2,
name:"Fresh Apples",
category:"Fruits",
brand:"Fresh Farm",
weight:"1 Kg",
price:149,
oldPrice:189,
rating:4.7,
offer:"20% OFF",
image:"https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=800&q=80"
},

{
id:3,
name:"Bananas",
category:"Fruits",
brand:"Organic",
weight:"1 Dozen",
price:69,
oldPrice:89,
rating:4.6,
offer:"22% OFF",
image:"https://images.unsplash.com/photo-1603833665858-e61d17a86224?auto=format&fit=crop&w=800&q=80"
},

{
id:4,
name:"Fresh Tomatoes",
category:"Vegetables",
brand:"Farm Fresh",
weight:"1 Kg",
price:39,
oldPrice:49,
rating:4.5,
offer:"20% OFF",
image:"https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=800&q=80"
},

{
id:5,
name:"Potatoes",
category:"Vegetables",
brand:"Local Farm",
weight:"2 Kg",
price:59,
oldPrice:79,
rating:4.6,
offer:"25% OFF",
image:"https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=800&q=80"
},

{
id:6,
name:"Lay's Chips",
category:"Snacks",
brand:"Lay's",
weight:"52 g",
price:20,
oldPrice:25,
rating:4.7,
offer:"15% OFF",
image:"https://images.unsplash.com/photo-1621939514649-280e2ee25f60?auto=format&fit=crop&w=800&q=80"
},

{
id:7,
name:"Coca Cola",
category:"Beverages",
brand:"Coca Cola",
weight:"750 ml",
price:45,
oldPrice:55,
rating:4.8,
offer:"18% OFF",
image:"https://images.unsplash.com/photo-1629203851122-3726ecdf080e?auto=format&fit=crop&w=800&q=80"
},

{
id:8,
name:"Brown Bread",
category:"Bakery",
brand:"Britannia",
weight:"400 g",
price:45,
oldPrice:55,
rating:4.5,
offer:"15% OFF",
image:"https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80"
}

];




function loadProducts(list){

let html="";

list.forEach(product=>{

html+=`

<div class="col-lg-3 col-md-4 col-sm-6 mb-4">

<div class="card product-card h-100 shadow-sm">

<div class="position-relative">

<img src="${product.image}" class="card-img-top product-image">

<span class="badge bg-danger offer-badge">

${product.offer}

</span>

<button class="wishlist-btn">

<i class="bi bi-heart"></i>

</button>

</div>

<div class="card-body">

<small class="text-success">

${product.brand}

</small>

<h5 class="mt-2">

${product.name}

</h5>

<p class="text-muted">

${product.weight}

</p>

<div class="mb-2">

⭐ ${product.rating}

</div>

<div class="d-flex align-items-center">

<h5 class="text-success me-2">

₹${product.price}

</h5>

<del class="text-muted">

₹${product.oldPrice}

</del>

</div>

<div class="mt-3 d-grid gap-2">

<button

class="btn btn-success addCart">

🛒 Add To Cart

</button>

<button

class="btn btn-outline-danger wishlist">

❤️ Wishlist

</button>

</div>

</div>

</div>

</div>

`;

});

document.getElementById("groceryProducts").innerHTML=html;

}

loadProducts(products);





let cart=0;

document.addEventListener("click",function(e){

if(e.target.classList.contains("addCart")){

cart++;

document.getElementById("cartCount").innerHTML=cart;

e.target.innerHTML="✔ Added";

e.target.classList.remove("btn-success");

e.target.classList.add("btn-dark");

}

});




document.addEventListener("click",function(e){

if(e.target.closest(".wishlist")){

alert("❤️ Added to Wishlist");

}

});





const searchBox=document.querySelector(".hero-search input");

searchBox.addEventListener("keyup",()=>{

let value=searchBox.value.toLowerCase();

const filtered=products.filter(item=>

item.name.toLowerCase().includes(value)

||

item.category.toLowerCase().includes(value)

||

item.brand.toLowerCase().includes(value)

);

loadProducts(filtered);

});





document.querySelectorAll(".category-card").forEach(card=>{

card.addEventListener("click",()=>{

let category=card.querySelector("h6").innerText;

const filtered=products.filter(item=>

item.category===category

);

loadProducts(filtered);

});

});