

document.addEventListener("DOMContentLoaded", function () {

    const loginForm = document.getElementById("loginForm");

    if (!loginForm) return;

    loginForm.addEventListener("submit", loginUser);

});


function togglePassword() {

    const password = document.getElementById("password");
    const eyeIcon = document.getElementById("eyeIcon");

    if (password.type === "password") {

        password.type = "text";

        eyeIcon.classList.replace("bi-eye", "bi-eye-slash");

    } else {

        password.type = "password";

        eyeIcon.classList.replace("bi-eye-slash", "bi-eye");

    }

}


function loginUser(e) {

    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const button = document.getElementById("loginBtn");

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const mobileRegex = /^[6-9]\d{9}$/;

    if (email === "") {

        alert("Please enter Email or Mobile Number.");

        return;

    }

    if (!(emailRegex.test(email) || mobileRegex.test(email))) {

        alert("Enter a valid Email or 10-digit Mobile Number.");

        return;

    }

    if (password === "") {

        alert("Password cannot be empty.");

        return;

    }

    if (password.length < 6) {

        alert("Password must contain at least 6 characters.");

        return;

    }


    button.disabled = true;

    button.innerHTML = `
        <span class="spinner-border spinner-border-sm me-2"></span>
        Logging In...
    `;


    setTimeout(() => {

        alert("🎉 Login Successful!");

        window.location.href = "../index.html";

    }, 2000);

}