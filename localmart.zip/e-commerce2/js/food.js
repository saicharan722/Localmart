const restaurants = [

{
    name:"Pizza Hut",
    cuisine:"Pizza • Italian",
    rating:"4.6",
    time:"25 mins",
    distance:"1.2 km",
    offer:"50% OFF",
    image:"https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=900&q=80"
},

{
    name:"Burger King",
    cuisine:"Burger • Fast Food",
    rating:"4.5",
    time:"20 mins",
    distance:"900 m",
    offer:"Buy 1 Get 1",
    image:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80"
},

{
    name:"Paradise Biryani",
    cuisine:"Biryani • Mughlai",
    rating:"4.8",
    time:"30 mins",
    distance:"2 km",
    offer:"30% OFF",
    image:"https://images.unsplash.com/photo-1701579231349-d7459c40919d?auto=format&fit=crop&w=900&q=80"
},

{
    name:"Chinese Wok",
    cuisine:"Chinese",
    rating:"4.4",
    time:"28 mins",
    distance:"1.8 km",
    offer:"Free Delivery",
    image:"https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=900&q=80"
}

];

let restaurantHTML="";

restaurants.forEach(res=>{

restaurantHTML+=`

<div class="col-lg-3 col-md-6 mb-4">

<div class="card restaurant-card shadow">

<div class="position-relative">

<img src="${res.image}" class="card-img-top restaurant-img">

<span class="offer-badge">

${res.offer}

</span>

</div>

<div class="card-body">

<h5>${res.name}</h5>

<p class="text-muted">

${res.cuisine}

</p>

<div class="d-flex justify-content-between">

<span>

⭐ ${res.rating}

</span>

<span>

${res.time}

</span>

</div>

<p class="mt-2">

📍 ${res.distance}

</p>

<a href="restaurant.html"

class="btn btn-success w-100">

View Menu

</a>

</div>

</div>

</div>

`;

});

const restaurantContainerEl = document.getElementById("restaurantContainer");
if (restaurantContainerEl) {
    restaurantContainerEl.innerHTML = restaurantHTML;
}




const foods=[

{
name:"Margherita Pizza",
price:249,
rating:4.8,
image:"https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=900&q=80"
},

{
name:"Chicken Burger",
price:179,
rating:4.7,
image:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80"
},

{
name:"Hyderabadi Biryani",
price:299,
rating:4.9,
image:"https://images.unsplash.com/photo-1701579231349-d7459c40919d?auto=format&fit=crop&w=900&q=80"
},

{
name:"Veg Noodles",
price:149,
rating:4.6,
image:"https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=900&q=80"
},

{
name:"Chocolate Cake",
price:399,
rating:4.9,
image:"https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=900&q=80"
},

{
name:"Cold Coffee",
price:129,
rating:4.7,
image:"https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=80"
}

];

let foodHTML="";

foods.forEach(food=>{

foodHTML+=`

<div class="col-lg-3 col-md-6 mb-4">

<div class="card food-card shadow">

<img src="${food.image}"

class="card-img-top food-img">

<div class="card-body">

<h5>${food.name}</h5>

<div class="d-flex justify-content-between">

<h4 class="text-success">

₹${food.price}

</h4>

<span>

⭐ ${food.rating}

</span>

</div>

<div class="mt-3 d-grid gap-2">

<button class="btn btn-success addCart">

🛒 Add To Cart

</button>

<button class="btn btn-outline-danger">

❤️ Wishlist

</button>

</div>

</div>

</div>

</div>

`;

});

const foodItemsEl = document.getElementById("foodItems");
if (foodItemsEl) {
    foodItemsEl.innerHTML = foodHTML;
}



let cart = 0;

document.addEventListener("click", function (e) {
    if (!e.target) return;
    if (e.target.classList && e.target.classList.contains("addCart")) {
        cart++;
        const cartCountEl = document.getElementById("cartCount");
        if (cartCountEl) cartCountEl.innerHTML = cart;
        try {
            alert("Item Added To Cart");
        } catch (err) {
            /* ignore */
        }
    }
});





let title=card.querySelector("h5").innerText.toLowerCase();
card.parentElement.style.display=
title.includes(value) ? "block":"none";


const searchInput = document.querySelector(".hero-search input");
if (searchInput) {
    searchInput.addEventListener("keyup", () => {
        let value = searchInput.value.toLowerCase();
        const cards = document.querySelectorAll(".food-card");
        cards.forEach(card => {
            const titleEl = card.querySelector("h5");
            const title = titleEl ? titleEl.innerText.toLowerCase() : "";
            if (card.parentElement) card.parentElement.style.display = title.includes(value) ? "block" : "none";
        });
    });
}



document.addEventListener("DOMContentLoaded", function () {
    const wrapper = document.getElementById("categoryWrapper");
    const leftBtn = document.getElementById("leftBtn");
    const rightBtn = document.getElementById("rightBtn");

    if (rightBtn && wrapper) {
        rightBtn.addEventListener("click", function () {
            wrapper.scrollBy({
                left: 500,
                behavior: "smooth"
            });
        });
    }

    if (leftBtn && wrapper) {
        leftBtn.addEventListener("click", function () {
            wrapper.scrollBy({
                left: -500,
                behavior: "smooth"
            });
        });
    }
});