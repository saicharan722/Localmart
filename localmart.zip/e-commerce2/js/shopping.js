const products = [

{
id:1,
name:"Men Regular Fit Cotton Shirt",
brand:"Levi's",
price:999,
oldPrice:1999,
rating:4.7,
image:"https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=600&q=80"
},

{
id:2,
name:"Women's Floral Dress",
brand:"H&M",
price:1499,
oldPrice:2999,
rating:4.8,
image:"https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=600&q=80"
},

{
id:3,
name:"Nike Running Shoes",
brand:"Nike",
price:3499,
oldPrice:5999,
rating:4.9,
image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80"
},

{
id:4,
name:"Adidas Hoodie",
brand:"Adidas",
price:2499,
oldPrice:3999,
rating:4.6,
image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=600&q=80"
},

{
id:5,
name:"Women's Handbag",
brand:"Caprese",
price:1999,
oldPrice:2999,
rating:4.5,
image:"https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&q=80"
},

{
id:6,
name:"Titan Analog Watch",
brand:"Titan",
price:2899,
oldPrice:4999,
rating:4.8,
image:"https://images.unsplash.com/photo-1523170335258-f5ed11844a49?auto=format&fit=crop&w=600&q=80"
},

{
id:7,
name:"Men Blue Jeans",
brand:"Wrangler",
price:1799,
oldPrice:2999,
rating:4.6,
image:"https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=600&q=80"
},

{
id:8,
name:"Women's Casual Shoes",
brand:"Puma",
price:2399,
oldPrice:4299,
rating:4.7,
image:"https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=600&q=80"
}

];

const container = document.getElementById("shoppingProducts");

let html = "";

products.forEach(product=>{

html += `

<div class="col-lg-4 col-md-6">

<div class="card product-card border-0 shadow">

<div class="position-relative">

<img src="${product.image}" class="card-img-top product-img">

<span class="badge bg-danger discount-badge">

${Math.round((1-product.price/product.oldPrice)*100)}% OFF

</span>

<button class="btn btn-light wishlist-btn">

<i class="bi bi-heart"></i>

</button>

</div>

<div class="card-body">

<h6 class="text-success">${product.brand}</h6>

<h5 class="product-title">${product.name}</h5>

<div class="mb-2">

<span class="badge bg-success">

★ ${product.rating}

</span>

</div>

<h4>

₹${product.price}

<small class="text-decoration-line-through text-muted">

₹${product.oldPrice}

</small>

</h4>

<div class="d-grid gap-2 mt-3">

<button class="btn btn-success add-cart">

<i class="bi bi-cart-plus"></i>

Add To Cart

</button>

<button class="btn btn-outline-dark">

Quick View

</button>

</div>

</div>

</div>

</div>

`;

});

container.innerHTML = html;

// Wishlist Toggle
document.querySelectorAll(".wishlist-btn").forEach(btn=>{

btn.addEventListener("click",function(){

this.classList.toggle("active");

const icon=this.querySelector("i");

icon.classList.toggle("bi-heart");
icon.classList.toggle("bi-heart-fill");

});

});

// Add To Cart
document.querySelectorAll(".add-cart").forEach(btn=>{

btn.addEventListener("click",function(){

this.innerHTML='<i class="bi bi-check-circle"></i> Added';

this.classList.remove("btn-success");

this.classList.add("btn-dark");

});

});